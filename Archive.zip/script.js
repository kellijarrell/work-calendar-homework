//orginize all variables at top for easy access
var momentDate = moment().format('dddd, MMMM Do YYYY');
var contianer = document.getElementsByClassName("contianer");
var pastBox = document.querySelector(".past");
var presentBox = document.querySelector(".present");
var futureBox = document.querySelector(".future");
var textArea = document.querySelector("textarea");

var tasks = [""];
//init();

(function displayTime(){
var displayMoment = $("#currentDay");
displayMoment.html(momentDate);
})();

// create a variable to retrieve data from container (at top)

//figure out what all goes inside container using css

//save button (.saveBtn .saveBtn i:hover)
//create save button and have it saving to local storage
// blocks for input (.time-block textarea)
//create input blocks
//These should change color based on if it is past present or future (.past .present .future) (if and statement based off of current time (use moments here again maybe))
//create a variable for each state options (past, present, future)
//Make it do user input is writen out in blocks  (.description)
//create empty array to start
// make it so input is saved to local storage
// .row
// .hour
  

// function init() {
//     var storedTasks = JSON.parse(localStorage.getItem("tasks"));

//     if (storedTasks !== null) {
//         tasks = storedTasks;
//     }

//     renderTask();
// }

// function storeTasks() {
//     localStorage.setItem("tasks", JSON.stringify(todos));
// }